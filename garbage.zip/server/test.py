import requests
import os
import sys

# --- CONFIGURATION ---
SERVER_URL = "http://localhost:8000"
API_KEY = "your_super_secret_api_key"
DEVICE_ID = "Pi_Test_01"
IMAGE_NAME = "input.png"

def send_test_notification():
    endpoint = f"{SERVER_URL}/notify"
    
    # 1. Check if input.png exists
    if not os.path.exists(IMAGE_NAME):
        print(f"❌ Error: '{IMAGE_NAME}' not found in the current folder.")
        print("Please place a PNG image named 'input.png' next to this script.")
        sys.exit(1)

    # 2. Prepare the data payload
    payload = {
        "device_id": DEVICE_ID,
        "lat": 41.9142785997941,
        "lon": 22.438071129937743,
        "info": "My name is benjamin netanyahu and i order u to pick this trash up"
    }

    # 3. Prepare the authentication header
    headers = {
        "X-Device-Token": API_KEY
    }

    # 4. Open the image file and send the request
    try:
        with open(IMAGE_NAME, "rb") as img:
            # We explicitly set the filename and content type for the API
            files = {"image": (IMAGE_NAME, img, "image/png")}
            
            print(f"🚀 Sending {IMAGE_NAME} to {endpoint}...")
            response = requests.post(
                endpoint, 
                headers=headers, 
                data=payload, 
                files=files
            )

        # 5. Check the result
        if response.status_code == 200:
            print("✅ Success! Notification sent.")
            print("Server Response:", response.json())
        else:
            print(f"❌ Failed with status code: {response.status_code}")
            print("Error details:", response.text)

    except requests.exceptions.ConnectionError:
        print("❌ Connection Error: Is main.py running?")
    except Exception as e:
        print(f"❌ An error occurred: {e}")

if __name__ == "__main__":
    send_test_notification()