import os
import glob
import datetime
import shutil
from fastapi import FastAPI, UploadFile, File, Form, Depends, Request, HTTPException, status
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import APIKeyHeader
from telegram import Bot, Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import uvicorn

# --- CONFIGURATION ---
API_KEY = "your_super_secret_api_key"
TELEGRAM_TOKEN = "8386079421:AAF8gwyBb-sfX0rKWiI_I8vSGQQtca9MDbs"
ADMIN_CHAT_ID = "8502517576"  # Update this after you get it from the bot!
STORAGE_DIR = "storage"

app = FastAPI()
templates = Jinja2Templates(directory="templates")
os.makedirs(STORAGE_DIR, exist_ok=True)
app.mount("/images", StaticFiles(directory=STORAGE_DIR), name="images")

bot_instance = Bot(token=TELEGRAM_TOKEN)
api_key_header = APIKeyHeader(name="X-Device-Token")

# --- BOT COMMANDS ---
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    await update.message.reply_text(f"🆔 **Your Telegram ID:** `{user_id}`", parse_mode="Markdown")

# --- API ENDPOINTS ---

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    image_files = glob.glob(f"{STORAGE_DIR}/**/*.png", recursive=True) + \
                  glob.glob(f"{STORAGE_DIR}/**/*.jpg", recursive=True)
    image_files.sort(key=os.path.getmtime, reverse=True)
    
    alerts = []
    for img_path in image_files:
        path_parts = img_path.split(os.sep)
        device_id = path_parts[-2]
        filename = os.path.basename(img_path)
        
        # Simple logic to find coordinates for this specific image from logs
        lat, lon = "0.0", "0.0"
        log_file = os.path.join(STORAGE_DIR, device_id, "logs.txt")
        if os.path.exists(log_file):
            # In a real app, use a DB. Here we just show the device's last known loc
            with open(log_file, "r") as f:
                last_line = f.readlines()[-1]
                try:
                    coords = last_line.split('] ')[1].split(' |')[0]
                    lat, lon = coords.split(', ')
                except: pass

        alerts.append({
            "device_id": device_id,
            "filename": filename,
            "lat": lat,
            "lon": lon,
            "timestamp": datetime.datetime.fromtimestamp(os.path.getmtime(img_path)).strftime('%Y-%m-%d %H:%M:%S')
        })
    return templates.TemplateResponse(request=request, name="index.html", context={"request": request, "alerts": alerts})

@app.post("/notify")
async def notify(
    device_id: str = Form(...),
    lat: float = Form(...),
    lon: float = Form(...),
    info: str = Form(...),
    image: UploadFile = File(...),
    token: str = Depends(api_key_header)
):
    if token != API_KEY:
        raise HTTPException(status_code=401)
    
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    device_path = os.path.join(STORAGE_DIR, device_id)
    os.makedirs(device_path, exist_ok=True)
    
    content = await image.read()
    img_ext = image.filename.split('.')[-1]
    img_name = f"{ts}_{device_id}.{img_ext}"
    full_path = os.path.join(device_path, img_name)
    
    with open(full_path, "wb") as f:
        f.write(content)

    with open(os.path.join(device_path, "logs.txt"), "a") as f:
        f.write(f"[{ts}] {lat}, {lon} | {info}\n")

    # TELEGRAM NOTIFICATION (FIXED)
    if ADMIN_CHAT_ID.isdigit():
        try:
            target_id = int(ADMIN_CHAT_ID)
            # 1. Send Location first (creates the map preview)
            await bot_instance.send_location(chat_id=target_id, latitude=lat, longitude=lon)
            # 2. Send Photo
            await bot_instance.send_photo(
                chat_id=target_id,
                photo=content,
                caption=f"🚨 *ALERT: {device_id}*\n📝 {info}\n📍 Coords: {lat}, {lon}",
                parse_mode="Markdown"
            )
        except Exception as e:
            print(f"❌ Telegram Error: {e}")

    return {"status": "ok"}

@app.delete("/delete/{device_id}/{filename}")
async def delete_alert(device_id: str, filename: str, token: str = Depends(api_key_header)):
    if token != API_KEY:
        raise HTTPException(status_code=401)
    
    file_path = os.path.join(STORAGE_DIR, device_id, filename)
    if os.path.exists(file_path):
        os.remove(file_path)
        return {"status": "deleted"}
    raise HTTPException(status_code=404)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)