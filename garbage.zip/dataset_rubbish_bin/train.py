import os
from ultralytics import YOLO

def train_model():
    model_variant = "yolov8n.pt"
    data_yaml = "data.yaml"
    checkpoint_path = "runs/detect/train/weights/last.pt"
    
    if os.path.exists(checkpoint_path):
        print(f"🔄 Found checkpoint at {checkpoint_path}. Resuming training...")
        model = YOLO(checkpoint_path)
        resume_flag = True
    else:
        print(f"🚀 Starting fresh training with {model_variant}...")
        model = YOLO(model_variant)
        resume_flag = False

    model.train(
        data=data_yaml,
        epochs=500,
        imgsz=640,
        batch=16,
        resume=resume_flag,
        project="runs/detect", 
        name="train",
        exist_ok=True
    )

if __name__ == "__main__":
    train_model()